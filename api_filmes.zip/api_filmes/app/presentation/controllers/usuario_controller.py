from fastapi import APIRouter

routes = APIRouter()
prefix = '/usuario'

@routes.get('/')
def todos_usuario():
    return []